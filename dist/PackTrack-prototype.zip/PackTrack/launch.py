"""Launch PackTrack's API and dashboard; demo by default, or --config for real cameras."""
import argparse
import os
from pathlib import Path
import signal
import socket
import subprocess
import sys
import tempfile
import time

import requests

ROOT = Path(__file__).resolve().parent


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path, help="measured camera config; disables synthetic demo")
    parser.add_argument("--api-port", type=int, default=8000)
    parser.add_argument("--dashboard-port", type=int, default=8501)
    args = parser.parse_args()
    if args.api_port == args.dashboard_port:
        parser.error("API and dashboard ports must differ")
    if args.config:
        args.config = args.config.resolve()
        from camera_tracking import Camera
        Camera.load_all(args.config)  # Fail before starting services if config is invalid.
    for port in (args.api_port, args.dashboard_port):
        if not 1 <= port <= 65535:
            parser.error("ports must be between 1 and 65535")
        with socket.socket() as probe:
            probe.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            try:
                probe.bind(("127.0.0.1", port))
            except OSError:
                parser.error(f"port {port} is in use. Stop the old app or choose --api-port 8010 --dashboard-port 8510")
    if not (ROOT / "assets/qr/test-labels.zip").exists():
        from tools.make_labels import generate
        generate()
    temporary = tempfile.TemporaryDirectory(prefix="packtrack-demo-") if not args.config else None
    env = {**os.environ, "PACKTRACK_API_BASE_URL": f"http://127.0.0.1:{args.api_port}",
           "PACKTRACK_DEMO": "0" if args.config else "1"}
    if temporary:
        env["PACKTRACK_DB_URL"] = f"sqlite:///{temporary.name}/demo.db"
        env["PACKTRACK_STALE_AFTER"] = "60"
    processes = []
    def stop_signal(*_):
        raise KeyboardInterrupt
    signal.signal(signal.SIGTERM, stop_signal)
    try:
        processes.append(subprocess.Popen([sys.executable, "-m", "uvicorn", "api:app", "--host", "127.0.0.1",
                          "--port", str(args.api_port), "--log-level", "warning"], cwd=ROOT, env=env))
        for _ in range(80):
            if processes[0].poll() is not None:
                raise RuntimeError("Tracking API stopped during startup")
            try:
                requests.get(env["PACKTRACK_API_BASE_URL"] + "/dashboard", timeout=1).raise_for_status()
                break
            except requests.RequestException:
                time.sleep(.25)
        else:
            raise RuntimeError("Tracking API did not start")
        processes.append(subprocess.Popen([sys.executable, "-m", "streamlit", "run", "dashboard.py",
                          "--server.address", "127.0.0.1", "--server.port", str(args.dashboard_port),
                          "--server.headless", "true", "--browser.gatherUsageStats", "false"], cwd=ROOT, env=env))
        if args.config:
            processes.append(subprocess.Popen([sys.executable, "track.py", "--config", str(args.config)], cwd=ROOT, env=env))
        url = f"http://127.0.0.1:{args.dashboard_port}"
        for _ in range(80):
            if processes[1].poll() is not None:
                raise RuntimeError("Dashboard stopped during startup")
            try:
                requests.get(url + "/_stcore/health", timeout=1).raise_for_status()
                break
            except requests.RequestException:
                time.sleep(.25)
        else:
            raise RuntimeError("Dashboard did not start")
        print(f"\nPackTrack is ready: {url}", flush=True)
        print("Open this URL in your browser. Keep this terminal running. Ctrl-C stops all services.", flush=True)
        if temporary:
            print("Demo: use 'Load into truck' or 'Auto-play pickups'. Data is temporary; no webcam is opened.\n", flush=True)
        else:
            print("Live mode: using configured cameras and the persistent application database.\n", flush=True)
        while all(p.poll() is None for p in processes):
            time.sleep(1)
        raise RuntimeError("A PackTrack service stopped. See its output above.")
    except KeyboardInterrupt:
        print("\nStopping PackTrack.", flush=True)
    finally:
        for process in reversed(processes):
            if process.poll() is None:
                process.terminate()
        for process in processes:
            try:
                process.wait(timeout=8)
            except subprocess.TimeoutExpired:
                process.kill()
                process.wait()
        if temporary:
            temporary.cleanup()


if __name__ == "__main__":
    main()
